package com.cg.service;

import java.util.List;
import java.util.Map;

import com.cg.bean.Accounts;
import com.cg.bean.Policy;
import com.cg.bean.UserRole;
import com.cg.dao.IInsuranceGenDao;
import com.cg.dao.InsuranceGenDaoImpl;
import com.cg.exception.InsuranceException;

public class InsuranceGenServiceImpl implements IInsuranceGenService
{
    IInsuranceGenDao dao=new InsuranceGenDaoImpl();
	@Override
	public String loginValidation(String username, String password) throws InsuranceException {
	 String role=dao.loginValidation(username, password);
		return role;
	}
	@Override
	public void createUser(UserRole userrole) throws Exception {
		// TODO Auto-generated method stub
		dao.createUser(userrole);
	}
	@Override
	public int createAccount(Accounts accounts) throws InsuranceException {
		// TODO Auto-generated method stub
		return dao.createAccount(accounts);
	}
	@Override
	public List<Policy> getPolicy(String username) throws InsuranceException {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public List<String> getQuestions(String buisnessSegId) throws Exception {
		// TODO Auto-generated method stub
		return dao.getQuestions(buisnessSegId);
	}
	@Override
	public List<String> getAnswers(String name) throws Exception {
		// TODO Auto-generated method stub
		return dao.getAnswers(name);
	}
	@Override
	public int createPolicy(double premium, double accountNo) throws Exception {
		// TODO Auto-generated method stub
		return dao.createPolicy(premium, accountNo);
	}
	@Override
	public double createPremium(Map<String, String> quesAnsMap)
			throws Exception {
		// TODO Auto-generated method stub
		return dao.createPremium(quesAnsMap);
	}
}
