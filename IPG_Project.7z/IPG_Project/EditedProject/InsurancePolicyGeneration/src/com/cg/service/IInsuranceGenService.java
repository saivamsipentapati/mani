package com.cg.service;

import java.util.List;
import java.util.Map;

import com.cg.bean.Accounts;
import com.cg.bean.Policy;
import com.cg.bean.UserRole;
import com.cg.exception.InsuranceException;


public interface IInsuranceGenService 
{
   public String loginValidation(String username,String password) throws InsuranceException;
   
   public void createUser(UserRole userole) throws Exception;
   
   public int createAccount(Accounts accounts) throws InsuranceException ;
   
   List<Policy> getPolicy(String username) throws InsuranceException;

   List<String> getQuestions(String buisnessSegId) throws Exception;

   List<String> getAnswers(String name) throws Exception;

   int createPolicy(double premium, double accountNo) throws Exception;

   double createPremium(Map<String, String> quesAnsMap) throws Exception;
}
