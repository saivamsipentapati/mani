package com.cg.dao;

import java.util.List;
import java.util.Map;

import com.cg.exception.InsuranceException;
import com.cg.bean.Accounts;
import com.cg.bean.Policy;
import com.cg.bean.UserRole;

public interface IInsuranceGenDao 
{
	   public String loginValidation(String username,String password) throws InsuranceException;
	   
	   public int createAccount(Accounts accounts) throws InsuranceException ;

	   List<Policy> getPolicy(String username) throws InsuranceException;

	   List<String> getQuestions(String buisnessSegId) throws Exception;

	   List<String> getAnswers(String name) throws Exception;
	
	   int createPolicy(double premium, double accountNo) throws Exception;

	   double createPremium(Map<String, String> quesAnsMap) throws Exception;
	
	   public void createUser(UserRole userole) throws Exception;
}
