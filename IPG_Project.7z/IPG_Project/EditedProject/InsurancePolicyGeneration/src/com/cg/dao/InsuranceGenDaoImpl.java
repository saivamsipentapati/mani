package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.cg.bean.Accounts;
import com.cg.bean.UserRole;
import com.cg.exception.InsuranceException;
import com.cg.bean.Policy;
import com.cg.util.UtilConn;

public class InsuranceGenDaoImpl implements IInsuranceGenDao {

	@Override
	public String loginValidation(String username, String password) throws InsuranceException 
	{
		String query1="select username, password,rolecode from user_role_tbl where username=? and password=?";
		System.out.println(username);
		System.out.println(password);
		String role="";
		try {
			Connection con=UtilConn.getConnection();
			
//			PreparedStatement ps=con.prepareStatement(query,ResultSet.TYPE_SCROLL_INSENSITIVE);
			PreparedStatement stmt=con.prepareStatement("select username, password,rolecode from user_role_tbl where username=? and password=?");
			//Statement stmt=con.createStatement(query1);
			
			stmt.setString(1, username);
			stmt.setString(2, password);
			ResultSet rs=stmt.executeQuery();
			if(rs.next())
			{
				role=rs.getString("rolecode");
				con.close();
			}
			else
			{
				throw new InsuranceException("Invalid Credentials");
			}
			
		} catch (SQLException e) {
			 e.printStackTrace();
		}
		return role;
	}

	@Override
	public int createAccount(Accounts accounts) throws InsuranceException {
		int accountNumber = 0;
		ResultSet resultSet = null;
		Connection con=UtilConn.getConnection();
		try
		{
		PreparedStatement statement = con.prepareStatement("insert into accounts_new_table values(account_seq.nextval,?,?,?,?,?,?,?)");
		statement.setString(1, accounts.getInsuredName());
		statement.setString(2, accounts.getInsuredStreet());
		statement.setString(3, accounts.getInsuredCity());
		statement.setString(4, accounts.getInsuredState());
		statement.setInt(5, accounts.getInsuredZip());
		statement.setString(6, accounts.getBusinessSegment());
		statement.setString(7, accounts.getUserName());
		// System.out.println("Hello");
		statement.executeUpdate();
		
		// System.out.println("Hello");
		statement = con.prepareStatement("select account_seq.currval from dual");
		resultSet = statement.executeQuery();
		resultSet.next();

		accountNumber = resultSet.getInt(1);
		
		con.commit();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new InsuranceException("Error in inserting account details");
		}

		
		return accountNumber;
	}
	@Override
	public List<Policy> getPolicy(String username) throws InsuranceException {
		List<Policy> policyList = new ArrayList<Policy>();
		Policy policy = null;
			Connection con = UtilConn.getConnection();
			try
			{
			String query = "SELECT P.POLICYNO, P.POLICYPREMIUM, A.ACCOUNTNO FROM POLICY_TBL P, ACCOUNTS_NEW_TaBLe A WHERE A.ACCOUNTNO = P.ACCOUNTNO AND A.USERNAME = ?";
			PreparedStatement pst = con.prepareStatement(query);
			pst.setString(1, username);
			ResultSet rst = pst.executeQuery();
			
			while(rst.next()){
			double policyno = rst.getDouble(1); //position policyno from table
			double policyprem = rst.getDouble(2); //position policyprem from table
			long accountNo = (long) rst.getDouble(3); //position accountNo from table
			policy = new Policy(policyno, policyprem, accountNo);
			policyList.add(policy);
			}
			}
			catch(Exception e)
			{
				throw new InsuranceException("Error is in getting policy");
			}
		return policyList;
	}
	@Override
	public void createUser(UserRole userrole) throws Exception {
			Connection con = UtilConn.getConnection();
			
			String query = "INSERT INTO USER_ROLE_TBL VALUES (?,?,?)";
			PreparedStatement pst = con.prepareStatement(query);
			pst.setString(1, userrole.getUserName());
			pst.setString(2, userrole.getPassword());
			pst.setString(3, userrole.getRoleCode());
			pst.executeUpdate();
			
			con.close();
		
	}

	@Override
	public List<String> getQuestions(String buisnessSegId) throws Exception {
		List<String> queslist = new ArrayList<String>();
			Connection con = UtilConn.getConnection();
			String query = "SELECT * FROM POLICY_QUESTIONS_TBL WHERE BUS_SEG_ID = ?";
			PreparedStatement pst = con.prepareStatement(query);
			pst.setString(1, buisnessSegId);
			ResultSet rst = pst.executeQuery();
			
			while(rst.next()){
				queslist.add(rst.getString(3)); //position Questions from table
			}
			
		return queslist;
	}
	@Override
	public List<String> getAnswers(String name) throws Exception {
		List<String> anslist = new ArrayList<String>();
			Connection con = UtilConn.getConnection();
			
			String query = "SELECT * FROM POLICY_QUESTIONS_TBL WHERE POL_QUES_DESC = ?";
			PreparedStatement pst = con.prepareStatement(query);
			pst.setString(1, name);
			ResultSet rst = pst.executeQuery();
			
			while(rst.next()){
				String ans1 = rst.getString(4); //position answer1 from table
				String ans2 = rst.getString(6); //position answer2 from table
				String ans3 = rst.getString(8); //position answer3 from table
				anslist.add(ans1);
				anslist.add(ans2);
				anslist.add(ans3);
			}
			
		return anslist;
	}
	@Override
	public int createPolicy(double premium, double accountNo) throws Exception {
		int id = 0;
			Connection con = UtilConn.getConnection();
			
			String query="INSERT INTO POLICY_TaBLe VALUES (POLICYNO_SEQ.NEXTVAL,?,?)";
			PreparedStatement pstmt=con.prepareStatement(query);
			pstmt.setDouble(1, premium);
			pstmt.setDouble(2, accountNo);
			pstmt.executeUpdate();
			String qry = "select policyno from policy_table where accountno = ?";
			PreparedStatement pst = con.prepareStatement(qry);
			pst.setDouble(1, accountNo);
			ResultSet rs = pst.executeQuery();
			if(rs.next())
				id = rs.getInt("policyno");
			
		return id;
	}
	@Override
	public double createPremium(Map<String, String> quesAnsMap) throws Exception {
		double premium = 0;
			Connection con = UtilConn.getConnection();
			
			String query = "SELECT POL_QUES_ANS_WEIGHTAGE FROM POLICY_WEIGHT_TBL WHERE POL_QUES_DESC = ? AND POL_QUES_ANS = ?";
			PreparedStatement pst = con.prepareStatement(query);
			Set<String> ques = quesAnsMap.keySet();
			for(String questions : ques){
			pst.setString(1, questions);
			pst.setString(2, quesAnsMap.get(questions));
			ResultSet rst = pst.executeQuery();
			
			if(rst.next()){
				premium += rst.getInt("POL_QUES_ANS_WEIGHTAGE");
			}
			}
			
		return premium;
	}
	

}
