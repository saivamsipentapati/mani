package com.cg.bean;

public class Policy {
	private double policyNumber;
	private double policyPremium;
	private double accountNo;
	public Policy(double policyNumber, double policyPremium, double accountNo) {
		super();
		this.policyNumber = policyNumber;
		this.policyPremium = policyPremium;
		this.accountNo = accountNo;
	}
	public double getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(double accountNo) {
		this.accountNo = accountNo;
	}
	public Policy() {
		super();
		
	}
	public double getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(double policyNumber) {
		this.policyNumber = policyNumber;
	}
	public double getPolicyPremium() {
		return policyPremium;
	}
	public void setPolicyPremium(double policyPremium) {
		this.policyPremium = policyPremium;
	}

	
}
