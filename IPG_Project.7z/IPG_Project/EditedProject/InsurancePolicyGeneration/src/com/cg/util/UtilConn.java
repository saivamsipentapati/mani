package com.cg.util;

import java.sql.Connection;
import java.sql.DriverManager;

import com.cg.exception.InsuranceException;

public class UtilConn 
{    
	
	public static Connection getConnection(){
	Connection con=null;
	try{
	String className="oracle.jdbc.driver.OracleDriver";
	String user="system";
	String pass="India123";
	String url="jdbc:oracle:thin:@localhost:1521:XE";
	Class.forName(className);
	con = DriverManager.getConnection(url, user, pass);
	} catch (Exception e) {
		e.printStackTrace();
	}
	return con;
}
}