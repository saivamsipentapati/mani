package com.cg.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.bean.Accounts;
import com.cg.bean.UserRole;
import com.cg.exception.InsuranceException;
import com.cg.service.IInsuranceGenService;
import com.cg.service.InsuranceGenServiceImpl;

public class client {
	
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		IInsuranceGenService service=new InsuranceGenServiceImpl();
		while(true)
		{
			String rolecode=null;
			System.out.println("Enter username");
			String username=scanner.nextLine();
			System.out.println("Enter Password");
			String password=scanner.nextLine();
			try {
				rolecode=service.loginValidation(username, password);
			} catch (InsuranceException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			switch(rolecode)
			{
			
			case "insured":
				System.out.println("Enter your choice");
				System.out.println("1. Create Account");
				int i=scanner.nextInt();
				scanner.nextLine();
				switch(i)
				{
				case 1:System.out.println("Enter Insured name");
				String iName = scanner.nextLine();
				System.out.println("Enter Insured Street");
				String iStreet = scanner.nextLine();
				System.out.println("Enter Insured City");
				String iCity = scanner.nextLine();
				System.out.println("Enter Insured State");
				String iState = scanner.nextLine();
				System.out.println("Enter Insured Zip");
				int iZip = scanner.nextInt();
				scanner.nextLine();
				System.out.println("Enter Job/Business");
				String iJob = scanner.nextLine();
				System.out.println("Enter Username");
				String iUserName = scanner.nextLine();
				Accounts accounts = new Accounts(iName, iStreet, iCity, iState, iZip, iJob, iUserName);
					try {
						int accountNo = service.createAccount(accounts);
						System.out.println("Account Created with AccountNo : "+accountNo);
					} catch (InsuranceException e) {
						System.out.println(""+e.getMessage());
					}
					break;
				}
			case "agent":
				System.out.println("Enter your choice");
				System.out.println("1. Create Account"+"2. Create Policy");
				i=scanner.nextInt();
				scanner.nextLine();
				switch(i)
				{
				case 1:System.out.println("Enter Insured name");
				String iName = scanner.nextLine();
				System.out.println("Enter Insured Street");
				String iStreet = scanner.nextLine();
				System.out.println("Enter Insured City");
				String iCity = scanner.nextLine();
				System.out.println("Enter Insured State");
				String iState = scanner.nextLine();
				System.out.println("Enter Insured Zip");
				int iZip = scanner.nextInt();
				scanner.nextLine();
				System.out.println("Enter Job/Business");
				String iJob = scanner.nextLine();
				System.out.println("Enter Username");
				String iUserName = scanner.nextLine();
				Accounts accounts = new Accounts(iName, iStreet, iCity, iState, iZip, iJob, iUserName);
					try {
						int accountNo = service.createAccount(accounts);
						System.out.println("Account Created with AccountNo : "+accountNo);
					} catch (InsuranceException e) {
						System.out.println(""+e.getMessage());
					}
					
				
				break;
			case 2:
				List<String> qList=new ArrayList<String>();
				List<String> aList=new ArrayList<String>();
				String businessId="";
				int answer = 0;
				int weightage = 0;
				double premium = 0;
				System.out.println("1. Restaurant");
				System.out.println("2. Vehicle");
				System.out.println("3. Apartment");
				System.out.println("4. General Merchant");
				System.out.println("Enter your choice");
				int choice=scanner.nextInt();
				scanner.nextLine();
				if(choice==1)
					businessId="10001";
				else if(choice==2)
					businessId="10002";
				else if(choice==3)
					businessId="10003";
				else if(choice==4)
					businessId="10004";
				try {
					qList = service.getQuestions(businessId);
					for(String ques : qList){
						System.out.println(" "+ques);
						aList = service.getAnswers(ques);
						int count=0;
						for(String ans : aList){
							count++;
							System.out.print(count+" "+ans+" ");
						}
						System.out.println("Select the choice ");
						answer = scanner.nextInt();
						scanner.nextLine();
						if(answer == 1)
							weightage = 200;
						else if(answer == 2)
							weightage = 400;
						else if(answer == 3)
							weightage = 600;
						premium += weightage;
						System.out.println();
					}
					System.out.println(""+premium);
					int accountNo = 10002;
					int policy = service.createPolicy(premium, accountNo);
					System.out.println("Policy Generated with Policy No : "+policy);
				} catch (Exception e) {
					System.out.println(""+e.getMessage());
				}
				
				}
				break;
			case "admin":
				System.out.println("Enter your choice");
				System.out.println("1. Create User"
						+ "2. Create Account"
						+"3. Create Policy");
				i=scanner.nextInt();
				scanner.nextLine();
				switch(i)
				{
				case 1:System.out.println("creating user");
				System.out.println("Enter username");
				String username1=scanner.nextLine();
				System.out.println("Enter password");
				String password1=scanner.nextLine();
				System.out.println("Enter Rolecode");
				rolecode=scanner.nextLine();
				UserRole userole=new UserRole(username1,password1,rolecode);
					try {
						service.createUser(userole);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						System.out.println(""+e.getMessage());
					}
					break;
				case 2:System.out.println("Enter Insured name");
				String iName = scanner.nextLine();
				System.out.println("Enter Insured Street");
				String iStreet = scanner.nextLine();
				System.out.println("Enter Insured City");
				String iCity = scanner.nextLine();
				System.out.println("Enter Insured State");
				String iState = scanner.nextLine();
				System.out.println("Enter Insured Zip");
				int iZip = scanner.nextInt();
				scanner.nextLine();
				System.out.println("Enter Job/Business");
				String iJob = scanner.nextLine();
				System.out.println("Enter Username");
				String iUserName = scanner.nextLine();
				Accounts accounts = new Accounts(iName, iStreet, iCity, iState, iZip, iJob, iUserName);
					try {
						int accountNo = service.createAccount(accounts);
						System.out.println("Account Created with AccountNo : "+accountNo);
					} catch (InsuranceException e) {
						System.out.println(""+e.getMessage());
					}
					break;
				case 3:
					List<String> qList=new ArrayList<String>();
					List<String> aList=new ArrayList<String>();
					String businessId="";
					int answer = 0;
					int weightage = 0;
					double premium = 0;
					System.out.println("1. Restaurant");
					System.out.println("2. Vehicle");
					System.out.println("3. Apartment");
					System.out.println("4. General Merchant");
					System.out.println("Enter your choice");
					int choice=scanner.nextInt();
					scanner.nextLine();
					if(choice==1)
						businessId="10001";
					else if(choice==2)
						businessId="10002";
					else if(choice==3)
						businessId="10003";
					else if(choice==4)
						businessId="10004";
					try {
						qList = service.getQuestions(businessId);
						for(String ques : qList){
							System.out.println(" "+ques);
							aList = service.getAnswers(ques);
							int count=0;
							for(String ans : aList){
								count++;
								System.out.print(count+" "+ans+" ");
							}
							System.out.println("Select the choice ");
							answer = scanner.nextInt();
							scanner.nextLine();
							if(answer == 1)
								weightage = 200;
							else if(answer == 2)
								weightage = 400;
							else if(answer == 3)
								weightage = 600;
							premium += weightage;
							System.out.println();
						}
						System.out.println(""+premium);
						int accountNo = 10002;
						int policy = service.createPolicy(premium, accountNo);
						System.out.println("Policy Generated with Policy No : "+policy);
					} catch (Exception e) {
						System.out.println(""+e.getMessage());
					}
					
				}
				break;
			}
		}
	}

}
