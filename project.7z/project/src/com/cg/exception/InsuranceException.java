package com.cg.exception;

public class InsuranceException extends Exception {

	public InsuranceException(String message)
	{
		super(message);
		

	}
public InsuranceException()
{
	super();
}
}
