package com.cg.utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.cg.exception.InsuranceException;
public class DBUtil {

	public static Connection getConnection() throws InsuranceException{
	
		
		Connection con=null;
		try{
			String className="oracle.jdbc.driver.OracleDriver";
			String username="system";
			String password="oracle";
			String url="jdbc:oracle:thin:@localhost:1521:XE"; //protocol:sub-protocol:type of driver:IP address:port number:type of edition
			Class.forName(className);
			con = DriverManager.getConnection(url,username,password);
			System.out.println("failed");
		}
		catch(SQLException | ClassNotFoundException e){
	   e.printStackTrace();
		}
		return con;
	}
}
