package com.cg.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.security.auth.login.AccountException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.entity.Accounts;
import com.cg.entity.Policy;
import com.cg.entity.PolicyQuestions;
import com.cg.entity.UserRole;
import com.cg.exception.InsuranceException;
import com.cg.service.IInsuranceQuoteService;
import com.cg.service.InsuranceQuoteServiceImpl;

/**
 * Servlet implementation class Servlet_2
 */
@WebServlet("*.com")
public class InsuranceServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
     
	IInsuranceQuoteService service=new InsuranceQuoteServiceImpl();
	
    /**
     * 
     
     * @see HttpServlet#HttpServlet()
     */
    public InsuranceServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		

		String url=request.getServletPath().trim();
		String message="";
		String resource=null;
		RequestDispatcher dispatcher=null;
		switch(url)
		{
		
	
	case"/usercreation.com" :
			String newusername=request.getParameter("userName");
			String newpassword=request.getParameter("password");
			String newrolecode=request.getParameter("userrole");
			int rcode=Integer.parseInt(newrolecode);
			UserRole user=new UserRole(newusername,newpassword,rcode);
			try {
				service.addUser(user);
				resource="usercreation.jsp";
				message="User Created";
			    request.setAttribute("message", message);
			} catch (Exception e) {
				resource="usercreation.jsp";
				message="Username already exists";
			    request.setAttribute("message", message);
			}
			
			dispatcher=request.getRequestDispatcher(resource);
			dispatcher.forward(request, response);
			break;
			
	case"/accountcreation.com" :
			String insuredName    =request.getParameter("InsuredName");
			String insuredStreet  =request.getParameter("InsuredStreet");
			String insuredCity    =request.getParameter("InsuredCity");
			String insuredState   =request.getParameter("InsuredState");
			int insuredZip     =Integer.parseInt(request.getParameter("InsuredZip"));
			String businessSegment=request.getParameter("BusinessSegment");
			String accountNumber  =request.getParameter("AccountNumber");
			long anumber=Long.parseLong(accountNumber);
			String userName=(String)request.getSession().getAttribute("username");
					           
			Accounts account =new Accounts(anumber, insuredName, insuredStreet, insuredCity, insuredState, insuredZip, businessSegment, userName);
			try
			{
				service.createAccount(account);
				resource="accountcreation.jsp";
				message="Account Created";
			}
			catch(Exception e)
			{
				  message=e.getMessage();
				  resource="accountcreation.jsp";
			}
				  request.setAttribute("message",message);
				  dispatcher=request.getRequestDispatcher(resource);
				  dispatcher.forward(request, response);
	  
			}		

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url=request.getServletPath().trim();
		String message="";
		String resource=null;
		RequestDispatcher dispatcher=null;
		switch(url)
		{
		case "/login.com" :  
				String username=request.getParameter("username");
				request.getSession().setAttribute("username", username);
				String password=request.getParameter("password");
			int rolecode=0;
			
		
			try {
				rolecode = service.login(username,password);
				request.getSession().setAttribute("rolecode", rolecode);
	
			    if(rolecode==1)
			    {
			    	resource="admin.jsp";
			    }
			    else if(rolecode==2)
			    {
			    	resource="agent.jsp";
			    }
			    else if(rolecode==3)
			    {
			    	resource="insured.jsp";
			    }
			    else if(rolecode==4)
			    {
			    	resource="ainsured.jsp";
			    }
			}
			   catch(Exception e)
			    {
			    	resource="login.jsp";
			    	message="Invalid Credentials";
			    	request.setAttribute("message", message);
			    
			    }
		    dispatcher=request.getRequestDispatcher(resource);
		    dispatcher.forward(request, response);
			    break;
		case "/policycreation.com" :
			String businessid=request.getParameter("businessSegment");
			request.setAttribute("businessseg", businessid);
			int acNo=Integer.parseInt(request.getParameter("accountnumber"));
			
			request.getSession().setAttribute("accountnumber", acNo);
		
			String user=(String)request.getSession().getAttribute("username");
			boolean flag=true;
			try {
				flag=service.checkaccount(acNo,user);
				if(flag)
				{
					resource="policycreation.jsp";
					message="This account No can't be accessed";
					request.setAttribute("message", message);

					
				}
				else {
				List<PolicyQuestions> policyQuestionsList=null;
				try {
					policyQuestionsList = service.returnQuestions(businessid);
					request.getSession().setAttribute("policyQuestionsList", policyQuestionsList);
					resource="displaypolicyques.jsp";
					
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				}
			} catch (InsuranceException e1) {
				resource="policycreation.jsp";
				message="Account No doesn't exist";
				request.setAttribute("message", message);

				
			}
			dispatcher=request.getRequestDispatcher(resource);
			dispatcher.forward(request, response);
			break;
			
		case "/policyanswers.com" :
			List<PolicyQuestions> list=(List<PolicyQuestions>) request.getSession().getAttribute("policyQuestionsList");
	        List<Integer> valueslist=null;
	         int premium=0;
	        for(PolicyQuestions pq:list)
	        {   
	        	String qid=pq.getBus_Seg_Id();
	        	int qans=Integer.parseInt(request.getParameter(qid));
	        	valueslist.add(qans);
	        }
	        
	        for(Integer i:valueslist)
	        {
	        	premium+=i;
	        }
	        long accountNumber=(Long)request.getSession().getAttribute("accountnumber");
	        long policyNumber=Integer.parseInt(request.getParameter("policynumber"));
	        Policy policy=new Policy(policyNumber,premium,accountNumber);
	        try {
				service.createPolicy(policy);
				resource="displaypolicyques.jsp";
				message="Policy created successfully";
				
			} catch (InsuranceException e) {
				resource="displaypolicyques.jsp";
				message="Policy Number aleady exists";
			}
			    request.setAttribute("message", message);
				dispatcher=request.getRequestDispatcher(resource);
				dispatcher.forward(request, response);
			
	        
		

		}

	}}
