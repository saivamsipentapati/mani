package com.cg.entity;



public class PolicyQuestions {

	private String Pol_Ques_Id;

	private int Pol_Ques_Seq;

	private String Bus_Seg_Id;

	private String Pol_Ques_Desc;

	private String Pol_Ques_Ans1;

	private int Pol_Ques_Ans1_weightage;

	private String Pol_Ques_Ans2;

	private int Pol_Ques_Ans2_weightage;

	private String Pol_Ques_Ans3;

	private int Pol_Ques_Ans3_weightage;

	private String Pol_Ques_Ans4;

	private int Pol_Ques_Ans4_weightage;

	public PolicyQuestions() {
		super();
	}

	public String getPol_Ques_Id() {
		return Pol_Ques_Id;
	}

	public void setPol_Ques_Id(String pol_Ques_Id) {
		Pol_Ques_Id = pol_Ques_Id;
	}

	public int getPol_Ques_Seq() {
		return Pol_Ques_Seq;
	}

	public void setPol_Ques_Seq(int pol_Ques_Seq) {
		Pol_Ques_Seq = pol_Ques_Seq;
	}

	public String getBus_Seg_Id() {
		return Bus_Seg_Id;
	}

	public void setBus_Seg_Id(String bus_Seg_Id) {
		Bus_Seg_Id = bus_Seg_Id;
	}

	public String getPol_Ques_Desc() {
		return Pol_Ques_Desc;
	}

	public void setPol_Ques_Desc(String pol_Ques_Desc) {
		Pol_Ques_Desc = pol_Ques_Desc;
	}

	public String getPol_Ques_Ans1() {
		return Pol_Ques_Ans1;
	}

	public void setPol_Ques_Ans1(String pol_Ques_Ans1) {
		Pol_Ques_Ans1 = pol_Ques_Ans1;
	}

	public int getPol_Ques_Ans1_weightage() {
		return Pol_Ques_Ans1_weightage;
	}

	public void setPol_Ques_Ans1_weightage(int pol_Ques_Ans1_weightage) {
		Pol_Ques_Ans1_weightage = pol_Ques_Ans1_weightage;
	}

	public String getPol_Ques_Ans2() {
		return Pol_Ques_Ans2;
	}

	public void setPol_Ques_Ans2(String pol_Ques_Ans2) {
		Pol_Ques_Ans2 = pol_Ques_Ans2;
	}

	public int getPol_Ques_Ans2_weightage() {
		return Pol_Ques_Ans2_weightage;
	}

	public void setPol_Ques_Ans2_weightage(int pol_Ques_Ans2_weightage) {
		Pol_Ques_Ans2_weightage = pol_Ques_Ans2_weightage;
	}

	public String getPol_Ques_Ans3() {
		return Pol_Ques_Ans3;
	}

	public void setPol_Ques_Ans3(String pol_Ques_Ans3) {
		Pol_Ques_Ans3 = pol_Ques_Ans3;
	}

	public int getPol_Ques_Ans3_weightage() {
		return Pol_Ques_Ans3_weightage;
	}

	public void setPol_Ques_Ans3_weightage(int pol_Ques_Ans3_weightage) {
		Pol_Ques_Ans3_weightage = pol_Ques_Ans3_weightage;
	}

	public String getPol_Ques_Ans4() {
		return Pol_Ques_Ans4;
	}

	public void setPol_Ques_Ans4(String pol_Ques_Ans4) {
		Pol_Ques_Ans4 = pol_Ques_Ans4;
	}

	public int getPol_Ques_Ans4_weightage() {
		return Pol_Ques_Ans4_weightage;
	}

	public void setPol_Ques_Ans4_weightage(int pol_Ques_Ans4_weightage) {
		Pol_Ques_Ans4_weightage = pol_Ques_Ans4_weightage;
	}

	public PolicyQuestions(String pol_Ques_Id, int pol_Ques_Seq, String bus_Seg_Id, String pol_Ques_Desc,
			String pol_Ques_Ans1, int pol_Ques_Ans1_weightage, String pol_Ques_Ans2, int pol_Ques_Ans2_weightage,
			String pol_Ques_Ans3, int pol_Ques_Ans3_weightage, String pol_Ques_Ans4, int pol_Ques_Ans4_weightage) {
		super();
		Pol_Ques_Id = pol_Ques_Id;
		Pol_Ques_Seq = pol_Ques_Seq;
		Bus_Seg_Id = bus_Seg_Id;
		Pol_Ques_Desc = pol_Ques_Desc;
		Pol_Ques_Ans1 = pol_Ques_Ans1;
		Pol_Ques_Ans1_weightage = pol_Ques_Ans1_weightage;
		Pol_Ques_Ans2 = pol_Ques_Ans2;
		Pol_Ques_Ans2_weightage = pol_Ques_Ans2_weightage;
		Pol_Ques_Ans3 = pol_Ques_Ans3;
		Pol_Ques_Ans3_weightage = pol_Ques_Ans3_weightage;
		Pol_Ques_Ans4 = pol_Ques_Ans4;
		Pol_Ques_Ans4_weightage = pol_Ques_Ans4_weightage;
	}

	
}
