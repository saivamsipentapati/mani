package com.cg.service;



import java.io.IOException;
import java.sql.SQLException;
import java.util.List;











import com.cg.daoinsurance.IInsuranceQuoteDao;
import com.cg.daoinsurance.InsuranceQuoteDaoImpl;
import com.cg.entity.Accounts;
import com.cg.entity.BusinessSegment;
import com.cg.entity.Policy;
import com.cg.entity.PolicyDetails;
import com.cg.entity.PolicyQuestions;
import com.cg.entity.UserRole;
import com.cg.exception.InsuranceException;

public class InsuranceQuoteServiceImpl implements IInsuranceQuoteService 
  {
	IInsuranceQuoteDao idao=new InsuranceQuoteDaoImpl();
	@Override
	public int login(String username, String password) throws InsuranceException   {
		
		int rolecode=0;
		
			try {
				rolecode = idao.login(username, password);
			} catch (Exception e) {
			throw new InsuranceException("Invalid Credentials");
			}		
		return rolecode;
	}
	@Override
	public void addUser(UserRole user) throws InsuranceException 
	{
	
			try {
				idao.addUser(user);
			} catch (Exception e) {
		      throw new InsuranceException("Username ALready Exists");
			}
			
		}
	@Override
	public void createAccount(Accounts account) throws InsuranceException {
		try {
			idao.createAccount(account);
		} catch (Exception e) {
			throw new InsuranceException("Account no already exists");
		}
		
	}
	@Override
	public void createPolicy(Policy policy) throws InsuranceException {
		idao.createPolicy(policy);
		
	}
	@Override
	public PolicyDetails returnPolicyDetails(int policynumber) throws Exception {
		PolicyDetails policydetails=idao.returnPolicyDetails(policynumber);
		return policydetails;
	}
	@Override
	public void setPolicyDetails(PolicyDetails policydetails) throws Exception {
		idao.setPolicyDetails(policydetails);
		
	}
	@Override
	public BusinessSegment returnBusinessSegment(int businessid) throws Exception {
		BusinessSegment businesssegment=idao.returnBusinessSegment(businessid);
		return businesssegment;
	}
	@Override
	public void setBusinessSegment(BusinessSegment businesssegment) throws Exception {
		idao.setBusinessSegment(businesssegment);
		
	}
	@Override
	public List<PolicyQuestions> returnQuestions(String businessid) throws Exception {
		List<PolicyQuestions> list=idao.returnQuestions(businessid);
		return list;
	}
	@Override
	public List<Policy> returnPolicy(long accountnumber) throws Exception {
		List<Policy> list=idao.returnPolicy(accountnumber);
		return list;
	}
	@Override
	public boolean checkaccount(int acNo,String user) throws InsuranceException{
		boolean flag;
		flag = idao.checkaccount(acNo,user);
		return flag;
	}
	
	
}
